export FLASK_APP=Model.py
python3 -m flask run